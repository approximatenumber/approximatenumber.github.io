
#include "lzf.h"

#define LZF_BUF_SIZE	0x2048

