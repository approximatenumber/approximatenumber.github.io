#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main( int argc, char *argv[] )
{
	if ( argc < 3 )
	{
		fprintf( stderr, "Usage: %s <sec> <command> [args]\n", argv[0] );
		exit( -1 );
	}

	sleep( atoi( argv[1] ) );
	if ( execv( argv[2], &argv[2] ) < 0 )
	{
		perror( "execv()" );
		exit( -1 );
	}

	return ( 0 );
}
